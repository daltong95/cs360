package com.example.daltongeigerproject2cs360;

public class UserModel {

    private int id;
    private String usernames;
    private String passwords;
    private String date;
    private String weight;
    private String goalweight;

    public UserModel(int id, String usernames, String passwords, String date, String weight, String goalweight) {
        this.id = id;
        this.usernames = usernames;
        this.passwords = passwords;
        this.date = date;
        this.weight = weight;
        this.goalweight = goalweight;
    }

    public UserModel(){}



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsernames() {
        return usernames;
    }

    public void setUsernames(String usernames) {
        this.usernames = usernames;
    }

    public String getPasswords() {
        return passwords;
    }

    public void setPasswords(String passwords) {
        this.passwords = passwords;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getGoalweight() {
        return goalweight;
    }

    public void setGoalweight(String goalweight) {
        this.goalweight = goalweight;
    }
}
