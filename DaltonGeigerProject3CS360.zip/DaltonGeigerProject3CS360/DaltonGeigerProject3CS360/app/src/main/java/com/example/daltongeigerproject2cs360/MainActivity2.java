package com.example.daltongeigerproject2cs360;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Notification;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity2 extends AppCompatActivity {
    // Variables

    public static final String EXTRA_NUMBER = "com.example.application.daltongeigerproject2cs360.EXTRA_NUMBER";

    Button btn_add, btn_create_goal;
    TextView et_date;
    TextView et_weight;



    List<String> et_dateList;
    List<String> et_weightList;
    TextView[][] et_toTextView = new TextView[7][2];

    UserDataBaseHelper userDataBaseHelper;


    Integer currentUser;

    Boolean notiActive = false;




    // First to run
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

         




        Intent intent = getIntent();

        currentUser = intent.getIntExtra(MainActivity.EXTRA_NUMBER, 0);





        // Set buttons
        btn_add = findViewById(R.id.btn_add);
        btn_create_goal = findViewById(R.id.createG_btn);

        // Set edit Text
        et_date = findViewById(R.id.et_dayofweek);
        et_weight = findViewById(R.id.et_weight);

        // Set edit text table entries
       et_toTextView[0][0] = findViewById(R.id.r1e1);      et_toTextView[0][1] = findViewById(R.id.r1e2);
        et_toTextView[1][0] = findViewById(R.id.r2e1);      et_toTextView[1][1] = findViewById(R.id.r2e2);
        et_toTextView[2][0] = findViewById(R.id.r3e1);      et_toTextView[2][1] = findViewById(R.id.r3e2);
        et_toTextView[3][0] = findViewById(R.id.r4e1);      et_toTextView[3][1] = findViewById(R.id.r4e2);
        et_toTextView[4][0] = findViewById(R.id.r5e1);      et_toTextView[4][1] = findViewById(R.id.r5e2);
        et_toTextView[5][0] = findViewById(R.id.r6e1);      et_toTextView[5][1] = findViewById(R.id.r6e2);
        et_toTextView[6][0] = findViewById(R.id.r7e1);      et_toTextView[6][1] = findViewById(R.id.r7e2);


        userDataBaseHelper = new UserDataBaseHelper(MainActivity2.this);

        // Display table when activity opens
        DisplayTable();



        // Set a function to the add button
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addWeightToTable();
                DisplayTable();
            }
        });


        btn_create_goal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                createGoalWeight();
            }
        });




    }


    private void DisplayTable() {
        // Get the date and weight in the WEIGHT_TABLE for the current user
        et_dateList = userDataBaseHelper.getDatesData(currentUser.toString());
        et_weightList = userDataBaseHelper.getWeightData(currentUser.toString());

        // Loop though the date list and only display the first seven entries
        for (int i = 0; i < et_dateList.size(); i++) {
            if(i < 7){
                et_toTextView[i][0].setText(et_dateList.get(i));

            }
        }

        // Loop though the date list and only display the first seven entries
        for (int i = 0; i < et_weightList.size(); i++) {
            if(i < 7){
                et_toTextView[i][1].setText(et_weightList.get(i));



            }
        }

        determineNotificationAct();
    }
    private void updateTable(){

        et_dateList = userDataBaseHelper.getDatesData(currentUser.toString());
        et_weightList = userDataBaseHelper.getWeightData(currentUser.toString());

        ArrayList<String> newDateEntry = new ArrayList<>();

        ArrayList<String> newWeightEntry= new ArrayList<>();

        for (int i = 0; i < 7; i++){


            if(!et_toTextView[i][0].getText().toString().isEmpty() && !et_toTextView[i][1].getText().toString().isEmpty()){
                newDateEntry.add(et_toTextView[i][0].getText().toString());
                newWeightEntry.add(et_toTextView[i][1].getText().toString());
            }
        }

        UserModel userModel = new UserModel(currentUser, null, null, null, null, null);

        userDataBaseHelper.deleteEntries(userModel);
        userDataBaseHelper.updateEntry(newDateEntry, newWeightEntry, userModel);

        newDateEntry.clear();
        newWeightEntry.clear();
        et_dateList.clear();
        et_weightList.clear();


    }

    // Function to add entries to table
    public void addWeightToTable(){

        UserModel userModel;

        userModel = new UserModel(currentUser,null, null, et_date.getText().toString(), et_weight.getText().toString(), null);

        UserDataBaseHelper userDataBaseHelper = new UserDataBaseHelper(MainActivity2.this);


        boolean success = userDataBaseHelper.addOneWeight(userModel);

        Toast.makeText(MainActivity2.this, "Success " + success, Toast.LENGTH_SHORT).show();

        determineNotificationAct();

    }
    // Create the goal weight from what is in the weight text view.
    public void createGoalWeight(){
        UserModel userModel;

        userModel = new UserModel(currentUser, null, null, null, null, et_weight.getText().toString());

        UserDataBaseHelper userDataBaseHelper = new UserDataBaseHelper(MainActivity2.this);

        boolean success = userDataBaseHelper.addGoalWeight(userModel);

        Toast.makeText(MainActivity2.this, "Success " + success, Toast.LENGTH_SHORT).show();
        if(!success){
            Toast.makeText(MainActivity2.this, "Enter Goal weight into weight" , Toast.LENGTH_SHORT).show();

        } else {
            openActivity3();
        }
    }

    // Next activity
    private void openActivity3(){

        int loginUserId = currentUser;

        Intent intent = new Intent(this, MainActivity3.class);
        intent.putExtra(EXTRA_NUMBER, loginUserId);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    // Finish function to use when user leaves the activity.
    @Override
    public void finish(){
        super.finish();;
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        updateTable();
    }

    // Determine if goal notification is active
    public void determineNotificationAct(){
        Intent intent = getIntent();

        notiActive = intent.getBooleanExtra(MainActivity3.EXTRA_ACTIVATION, false);
        Toast.makeText(MainActivity2.this, notiActive.toString(), Toast.LENGTH_SHORT).show();

        for (int i = 0; i < 7; i++) {
            if (notiActive && et_toTextView[i][1].getText().toString().equals(userDataBaseHelper.compareGoal(currentUser.toString()))) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {


                    channelNotification();
                }

                sendNotification();

            }
        }
    }

    // Setup Notification
    public void sendNotification () {

        NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity2.this, "My Notification");
        builder.setContentTitle("Goal weight");
        builder.setContentText("You have meet your goal!");
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setAutoCancel(true);



        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivity2.this);
        managerCompat.notify(1, builder.build());

    }
    // Notification channel setup
    public void channelNotification(){
        NotificationChannel channel = new NotificationChannel("My Notification", "My Notification", NotificationManager.IMPORTANCE_HIGH);
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }
}

