package com.example.daltongeigerproject2cs360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class UserDataBaseHelper extends SQLiteOpenHelper {
    public static final String USER_TABLE = "USER_TABLE";
    public static final String ID = "ID";
    public static final String USERNAMES = "USERNAMES";
    public static final String PASSWORD = "PASSWORD";

    public static final String WEIGHT_TABLE = "WEIGHT_TABLE";
    public static final String DATE = "DATE";
    public static final String WEIGHT = "WEIGHT";



    public static final String GOAL_TABLE = "GOAL_TABLE";
    public static final String GOAL_WEIGHT = "GOAL_WEIGHT";

    private static final String createTable1 = "CREATE TABLE " + USER_TABLE + " ("
            + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + USERNAMES + " TEXT, "
            + PASSWORD + " TEXT);";

    private static final String createTable2 = "CREATE TABLE " + WEIGHT_TABLE + " ("
            + ID + " INTEGER, "
            + DATE + " TEXT, "
            + WEIGHT + " TEXT);";

    private static final String createTable3 = "CREATE TABLE " + GOAL_TABLE + " ("
            + ID + " INTEGER, "
            + GOAL_WEIGHT + " TEXT);";

    public UserDataBaseHelper(@Nullable Context context) {
        super(context, "database.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){

        db.execSQL(createTable1);
        db.execSQL(createTable2);
        db.execSQL(createTable3);
        
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }
    // Create a new user to the database
    public boolean addOneUser(UserModel userModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        cv.put(USERNAMES, userModel.getUsernames());
        cv.put(PASSWORD, userModel.getPasswords());

        long insert = db.insert(USER_TABLE, null, cv);


        if(insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public boolean addOneWeight(UserModel userModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(ID, userModel.getId());
        cv.put(DATE, userModel.getDate());
        cv.put(WEIGHT, userModel.getWeight());

        long insert = db.insert(WEIGHT_TABLE, null, cv);


        if(insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public boolean addGoalWeight(UserModel userModel){
        SQLiteDatabase db = this.getWritableDatabase();

        deleteGoalEntries(userModel);

        ContentValues cv = new ContentValues();

        cv.put(ID, userModel.getId());
        cv.put(GOAL_WEIGHT, userModel.getGoalweight());

        long insert = db.insert(GOAL_TABLE, null, cv);

        if(insert == -1){
            return false;
        }else {
            return true;
        }
    }

    public String compareGoal(String id){
        SQLiteDatabase db = getReadableDatabase();
        String result = "";

        String sql = "select * from " + GOAL_TABLE + " where " + ID + " = " + Integer.parseInt(id);
        Cursor cursor = db.rawQuery(sql,null);

        if (cursor.moveToFirst()){
            do{
                result = cursor.getString(1);
            }while (cursor.moveToNext());
        }
        cursor.close();
        return result;
    }


    public String findUser(String user) {
        SQLiteDatabase db = getReadableDatabase();

        String result = "";
        String sql = "select * from " + UserDataBaseHelper.USER_TABLE + " where USERNAMES = '" + user + "'";
        Cursor cursor = db.rawQuery(sql, null);

        if(cursor.moveToFirst()){
         do{
             result = cursor.getString(2);


         }while (cursor.moveToNext());
        }
        cursor.close();
        return result;
    }

    public String findID (String user){
        SQLiteDatabase db = getReadableDatabase();

        String result = "";
        String sql = "select * from " + UserDataBaseHelper.USER_TABLE + " where USERNAMES = '" + user + "'";
        Cursor cursor =db.rawQuery(sql, null);

        if(cursor.moveToFirst()){
            do{
                result = cursor.getString(0);
            }while (cursor.moveToNext());
        }
        cursor.close();
        return result;
    }

    public List<String> getDatesData(String id) {
        List<String> output = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + UserDataBaseHelper.WEIGHT_TABLE + " where ID = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);

        if(cursor.moveToFirst()){
            do{
                String dateEntry = cursor.getString(1);
                output.add(dateEntry);
            }while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return output;

    }

    public List<String> getWeightData(String id) {
        List<String> output = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + UserDataBaseHelper.WEIGHT_TABLE + " where ID = '" + id + "'";
        Cursor cursor = db.rawQuery(sql, null);

        if(cursor.moveToFirst()){
            do{
                String dateEntry = cursor.getString(2);
                output.add(dateEntry);
            }while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return output;

    }

    // Delete TABLE
    public boolean deleteEntries(UserModel userModel){
        SQLiteDatabase db = this.getWritableDatabase();

        String queryString = "DELETE FROM " + WEIGHT_TABLE + " WHERE " + ID + " = " + userModel.getId();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            return true;
        }else {
            return false;
        }
    }

    public boolean deleteGoalEntries(UserModel userModel){
        SQLiteDatabase db = this.getWritableDatabase();

        String queryString = "DELETE FROM " + GOAL_TABLE + " WHERE " + ID + " = " + userModel.getId();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            return true;
        }else {
            return false;
        }
    }

  public void updateEntry(ArrayList<String> newDateEntry, ArrayList<String> newWeightEntry, UserModel userModel){
        SQLiteDatabase db = this.getWritableDatabase();
        // Update TABLE
      for(int i = 0; i < newDateEntry.size(); i++) {
          ContentValues contentValues = new ContentValues();
          contentValues.put(ID, userModel.getId());
          contentValues.put(DATE, newDateEntry.get(i));
          contentValues.put(WEIGHT, newWeightEntry.get(i));
          long insert = db.insert(WEIGHT_TABLE, null, contentValues);
      }
    }

}
