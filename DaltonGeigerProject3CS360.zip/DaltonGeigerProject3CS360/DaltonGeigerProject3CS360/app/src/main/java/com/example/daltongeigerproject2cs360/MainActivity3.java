package com.example.daltongeigerproject2cs360;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity3 extends AppCompatActivity {


    public static final String EXTRA_ACTIVATION = "com.example.application.daltongeigerproject2cs360.EXTRA_ACTIVATION";
    public static final String EXTRA_NUMBER = "com.example.application.daltongeigerproject2cs360.EXTRA_NUMBER";
    // Variable buttons
    Button yes_btn, no_btn;

    Boolean activateNo = false;

    int currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Intent intent = getIntent();

        currentUser = intent.getIntExtra(MainActivity.EXTRA_NUMBER, 0);

        // Set up buttons
        yes_btn = findViewById(R.id.yes_btn);
        no_btn = findViewById(R.id.no_btn);

        // Yes button activates notification then returns to activity 2
        yes_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activateNo = true;
                OpenActivity2();
            }
        });

        // No button which will return to activity 2
        no_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activateNo = false;
                OpenActivity2();
            }
        });

    }

    void OpenActivity2(){
        int loginUserId = currentUser;
        Intent intent = new Intent(this, MainActivity2.class);

        intent.putExtra(EXTRA_ACTIVATION, activateNo);
        intent.putExtra(EXTRA_NUMBER, loginUserId);


        startActivity(intent);
        overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_right);
    }

    @Override
    public void finish(){
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}