package com.example.daltongeigerproject2cs360;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.DatePicker;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // For passing user's Id to the next activity to display only that user's data.
    public static final String EXTRA_NUMBER = "com.example.application.daltongeigerproject2cs360.EXTRA_NUMBER";
    //Text fields
    EditText usernameText;
    EditText passwordText;

    //Buttons
    Button loginButton;
    Button signupButton;

    private List<String> userList;
    private List<String> passwordList;

    UserDataBaseHelper userDataBaseHelper;

    MainActivity2 mainActivity2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Establish each text field and button
        usernameText = findViewById(R.id.username);
        passwordText = findViewById(R.id.password);
        loginButton = findViewById(R.id.button);
        signupButton = findViewById(R.id.button2);


        userDataBaseHelper = new UserDataBaseHelper(MainActivity.this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkForUser();
            }
        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                addUserAndPassword();
                }
            }
        );
    }

    private void openActivity2(){

        int loginUserId = Integer.parseInt(userDataBaseHelper.findID(usernameText.getText().toString()));

        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra(EXTRA_NUMBER, loginUserId);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

    }


    public void addUserAndPassword() {

        UserModel userModel;



        try {


            userModel = new UserModel(1, usernameText.getText().toString(), passwordText.getText().toString(), null, null, null);




            Toast.makeText(MainActivity.this, usernameText.getText().toString() + " added", Toast.LENGTH_SHORT).show();
        }
        // In case of error
        catch (Exception e){
            // Error message
            Toast.makeText(MainActivity.this, "Sign Up error.", Toast.LENGTH_SHORT).show();

            // Alternative error entry
            userModel = new UserModel(1, usernameText.getText().toString(), passwordText.getText().toString(), null, null, null);


        }

        // Set up UserDataBaseHelper
        UserDataBaseHelper userDataBaseHelper = new UserDataBaseHelper(MainActivity.this);

        boolean success = userDataBaseHelper.addOneUser(userModel);

        Toast.makeText(MainActivity.this, " Success " + success, Toast.LENGTH_SHORT).show();

    }


    // Display wrong password message
    public void wrongUserPassword(){
        Toast.makeText(MainActivity.this, "Username or password is wrong.", Toast.LENGTH_SHORT).show();

    }

    //Check database for existing user.
    public void checkForUser(){

        String userNameoutput = userDataBaseHelper.findUser(usernameText.getText().toString());


        try {
            if(passwordText.getText().toString().equals(userNameoutput)) {


                openActivity2();

            }else {
                wrongUserPassword();
            }

        }catch (Exception e) {
            Toast.makeText(MainActivity.this, "Results error", Toast.LENGTH_SHORT).show();
        }
    }
}